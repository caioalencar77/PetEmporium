<?php
header("Content-Type: text/plain");

// Configurações de erro (para desenvolvimento)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$response = "";

try {
    $conn = new mysqli("localhost", "root", "", "tccsim");
    
    if ($conn->connect_error) {
        throw new Exception("db_connection_failed");
    }

    if (!isset($_POST["nome"]) || !isset($_POST["senha"])) {
        throw new Exception("missing_parameters");
    }

    $nome = $conn->real_escape_string($_POST["nome"]);
    $senha = $conn->real_escape_string($_POST["senha"]);

    $stmt = $conn->prepare("SELECT id FROM usuarios WHERE nome = ? AND senha = ?");
    if (!$stmt) {
        throw new Exception("prepare_statement_failed");
    }

    $stmt->bind_param("ss", $nome, $senha);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $response = "success";
    } else {
        $response = "invalid_credentials";
    }

    $stmt->close();
    $conn->close();

} catch (Exception $e) {
    $response = $e->getMessage();
}

echo $response;
?>