<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tccsim";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

$nome = $_POST['nome'];
$senha = $_POST['senha'];

$sql = "SELECT * FROM usuarios WHERE nome = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $nome);
$stmt->execute();
$result = $stmt->get_result();

if ($user = $result->fetch_assoc()) {
    if ($senha === $user['senha']) { 
        $_SESSION['usuario'] = $user['nome'];
        echo "OK";
        exit();
    }
}

echo "Usuário ou senha incorretos.";
?>