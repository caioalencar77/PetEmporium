<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- css -->
    <link rel="stylesheet" href="..//home/style.css">
    <!-- card -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200&icon_names=arrow_forward" />
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
    <!-- Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200&icon_names=pets" />
    <title>TECESSAS</title>
    <!--bootstrap-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DynaPuff:wght@400..700&display=swap" rel="stylesheet">
</head>

<body>

    <!-- <button class="botao-mostrar" onclick="">mostrar</button>
    <button class="botao-esconder" onclick="">esconder</button>

    <div class="parte-inicio-2">
        <p>zxdftviyrbfubgi7ow</p>
        <p>zxdftviyrbfubgi7ow</p>
        <p>zxdftviyrbfubgi7ow</p>
        <p>zxdftviyrbfubgi7ow</p>
        <p>zxdftviyrbfubgi7ow</p>
    </div> -->

    <!-- <div class="parte-inicio-1"> -->

        <div class="background-inicio">

            <div class="base-top-area-inicial">
                <div class="img-inicio">
                    <img src="..//imagens/logomenor.png" alt="" class="img">
                </div>
                <div class="btn-inicial">
                    <a href="..//logincaio/index.php" style="text-decoration: none;">
                        <button class="btn-trans">Login</button>
                    </a>
                    <a href="../cadastro/index.php" style="text-decoration: none;">
                        <button class="btn-ntrans">Cadastrar</button>
                    </a>
                </div>
                
            </div>

  

            <div class="area-inicial">
                            <!-- Titulo e imagem do cachorro -->
                    <div class="titulo-area">
                            <div class="">
                                    <div class="titulos">
                                        <h1 class="dynapuff">Pet Emporium</h1><br>
                                        <h2 class="dynapuff">Fazendo o bem <br> para quem nos faz bem!</h2>    
                                    </div>
                                    <img src="..//imagens/gifcachorro2.gif" class="gif-cao" alt="">
                            </div>
                        </div>
                                <!-- Serviços -->
                                
                            <div class="servicos">
                                
                                    <h1 class="dynapuff">Conheça Nossos Serviços: </h1><br><br>
                            

                                <div class="itens-servicos">
                                <div class="bloco1">
                                    <div class="itens">
                                        <a href="" class="icon" style="text-decoration: none;">
                                            <img src="../imagens/sacolas-de-compras.png" alt="Sacola de Compras">
                                            <p class="texto-icon">Loja</p>
                                        </a>
                                    </div>
                                    <div class="itens">
                                        <a href="" class="icon" style="text-decoration: none;">
                                            <img src="..//imagens/assistente-virtual.png" alt="Assistente Virtual">
                                            <p class="texto-icon">Assistente</p>
                                        </a>
                                    </div>
                                </div>
                    
                                <div class="bloco2">
                                    <div class="itens">
                                        <a href="" class="icon" style="text-decoration: none;">
                                            <img src="../imagens/cachorro.png" alt="Adoção">
                                            <p class="texto-icon">Adoção</p>
                                        </a>
                                        </div>
                                    <div class="itens">
                                        <a href="" class="icon" style="text-decoration: none;">
                                            <img src="../imagens/mapa-do-tesouro.png" alt="Mapa">
                                            <p class="texto-icon">Mapa</p>
                                        </a>
                                    </div>   
                                </div>
                    
                                <div class="bloco3">
                                    <div class="itens">
                                        <a href="" class="icon" style="text-decoration: none;">
                                        <img src="..//imagens/bolsa-de-dinheiro.png" alt="Assinatura">
                                        <p class="texto-icon">Planos</p>
                                        </a>
                                    </div>
                                    <div class="itens">
                                        <a href="" class="icon" style="text-decoration: none;">
                                        <img src="..//imagens/sobre-nos.png" alt="Sobre nós">
                                            <p class="texto-icon">Sobre</p>
                                        </a>
                                    </div>
                                </div>
        
                            </div>  
                            
                        </div>
           

        </div>
    <!-- </div> -->

    <!-- Cards Responsivos:  -->
    <!-- <div class="container swiper">
        <div class="card-wrapper">
            <ul class="card-list swiper-wrapper"> -->
                <!-- card 1 -->
                <!-- <li class="card-item swiper-slide">
                    <a href="#" class="card-link">
                        <img src="https://embratur.com.br/wp-content/uploads/2022/07/Embratur-Brasil-ultrapassa-marca-de-1-milhao-de-turistas-estrangeiros-recebidos-pela-primeira-vez-desde-2020-1.png" alt="Card Image" class="card-image">
                        <p class="badge">Developer</p>
                        <h2 class="card-title">aaaaaaaaaaaaaa cffhnfjyntrydr dyrhjy5s4hs4 thahtea5hawe sheta3j3 sehte</h2>
                        <button class="card-button material-symbols-outlined">
                            arrow_forward
                        </button>
                    </a>
                </li> -->
                <!-- card 2 -->
                <!-- <li class="card-item swiper-slide">
                    <a href="#" class="card-link">
                        <img src="https://embratur.com.br/wp-content/uploads/2022/07/Embratur-Brasil-ultrapassa-marca-de-1-milhao-de-turistas-estrangeiros-recebidos-pela-primeira-vez-desde-2020-1.png" alt="Card Image" class="card-image">
                        <p class="badge1">Developer1</p>
                        <h2 class="card-title">aaaaaaaaaaaaaa cffhnfjyntrydr dyrhjy5s4hs4 thahtea5hawe sheta3j3 sehte</h2>
                        <button class="card-button material-symbols-outlined">
                            arrow_forward
                        </button>
                    </a>
                </li> -->
                <!-- card 3 -->
                <!-- <li class="card-item swiper-slide">
                    <a href="#" class="card-link">
                        <img src="https://embratur.com.br/wp-content/uploads/2022/07/Embratur-Brasil-ultrapassa-marca-de-1-milhao-de-turistas-estrangeiros-recebidos-pela-primeira-vez-desde-2020-1.png" alt="Card Image" class="card-image">
                        <p class="badge2">Developer2</p>
                        <h2 class="card-title">aaaaaaaaaaaaaa cffhnfjyntrydr dyrhjy5s4hs4 thahtea5hawe sheta3j3 sehte</h2>
                        <button class="card-button material-symbols-outlined">
                            arrow_forward
                        </button>
                    </a>
                </li> -->
                <!-- card 4 -->
                <!-- <li class="card-item swiper-slide">
                    <a href="#" class="card-link">
                        <img src="https://embratur.com.br/wp-content/uploads/2022/07/Embratur-Brasil-ultrapassa-marca-de-1-milhao-de-turistas-estrangeiros-recebidos-pela-primeira-vez-desde-2020-1.png" alt="Card Image" class="card-image">
                        <p class="badge3">Developer3</p>
                        <h2 class="card-title">aaaaaaaaaaaaaa cffhnfjyntrydr dyrhjy5s4hs4 thahtea5hawe sheta3j3 sehte</h2>
                        <button class="card-button material-symbols-outlined">
                            arrow_forward
                        </button>
                    </a> -->
                <!-- </li> -->
                <!-- card 5 -->
                <!-- <li class="card-item swiper-slide">
                    <a href="#" class="card-link">
                        <img src="https://embratur.com.br/wp-content/uploads/2022/07/Embratur-Brasil-ultrapassa-marca-de-1-milhao-de-turistas-estrangeiros-recebidos-pela-primeira-vez-desde-2020-1.png" alt="Card Image" class="card-image">
                        <p class="badge4">Developer4</p>
                        <h2 class="card-title">aaaaaaaaaaaaaa cffhnfjyntrydr dyrhjy5s4hs4 thahtea5hawe sheta3j3 sehte</h2>
                        <button class="card-button material-symbols-outlined">
                            arrow_forward
                        </button>
                    </a>
                </li>
            </ul> -->
            <!-- slider -->
            <!-- <div class="swiper-pagination"></div> -->
            <!-- botões para passar -->
            <!-- <div class="swiper-slide-button swiper-button-prev"></div>
            <div class="swiper-slide-button swiper-button-next"></div>
        </div>
    </div>  -->

    <!-- Link Swiper25 script -->
        <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

    <!-- linkando com o script.js -->
     <script src="..//home/js.js"></script>
    
</body>

</html>