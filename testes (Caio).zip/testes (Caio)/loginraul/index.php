<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Pet Emporium</title>
  <link rel="stylesheet" href="style.css"/>
</head>
<body>
  <main class="container">
    <section class="left" aria-label="Imagem de um cachorro">
      <img src="../imagens/gabzin cachorro.png" alt="Cachorro estiloso" />
    </section>
    <section class="right" aria-label="Login">
      <h2>Bem-vindo ao...</h2>
      <h1>Pet Emporium!</h1>
      <a href="../cadastro/index.php">
      <p>Não tem uma conta ainda? <a href="#">Inscrever-se</a></p>
      </a>
      <form>
        <label for="usuario">Usuário</label>
        <input type="text" id="usuario" name="usuario" required />

        <label for="senha">Senha</label>
        <input type="password" id="senha" name="senha" required />

        <div class="options">
          <label><input type="checkbox" /> Mantenha-me logado</label>
          <a href="#">Esqueceu a senha?</a>
        </div>

        <button type="submit">Login</button>
      </form>
    </section>
  </main>
</body>
</html>
