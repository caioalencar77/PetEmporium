<?php
    include"conexao.php";
    $con;
$emailx = $_POST["email"];
$senhax = $_POST["senha"];
$usuariox = $_POST["usuario"];
//$fotox=$_POST["fotox"];
//$loginx="luciano";
//$senhax="250955";
// $fotox="imagem.jpg";
    $comando= "Insert into cad2(email,senha,usuario) values ( '$emailx','$senhax','$usuariox')";
    $resulta = mysqli_query($con,$comando);

    if ($resulta!=0) {
       $dados=array("status"=>"ok");
    }
    else
      {   $dados=array("status"=>"erro");
}
echo json_encode($dados);
?>
