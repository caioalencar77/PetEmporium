
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <div class="container">
        <div class="main">
            <img src="..//imagens/gifcachorro2.gif" alt="" class="dog">
        </div>
        <div class="main2">
            <div class="formulario">
                <form action="funcaocad.php" method="POST" id="form">
                        <h1>Cadastro</h1>
                        <label for="">Usuario</label>
                        <input type="text" name="usuario" required >
                        <label for="Email">Email</label>
                        <input type="text" name="email" required >
                        <label for="">Senha</label>
                        <input type="password" name="senha" required >
                        <input type="submit" value="Cadastrar">
                    </form>
            </div>
        </div>
    </div>
</body>
</html>