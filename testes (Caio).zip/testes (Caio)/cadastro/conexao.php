
<?php
 //conectando com o server e o db
 $con = mysqli_connect('localhost',
                        'root',
                         '',
                         'registros');
//Verificando status
if(!$con){
    die('Erro ao conectar!!');
}
?>