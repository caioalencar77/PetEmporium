-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 07/06/2025 às 18:22
-- Versão do servidor: 8.3.0
-- Versão do PHP: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `registros`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `cad2`
--

DROP TABLE IF EXISTS `cad2`;
CREATE TABLE IF NOT EXISTS `cad2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `usuario` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `senha` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `foto` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`,`email`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `cad2`
--

INSERT INTO `cad2` (`id`, `email`, `usuario`, `senha`, `foto`) VALUES
(5, 'victorcintra@gmail.com.gov', 'Cintra', '123456', ''),
(9, 'bernardopetti@gmail.com', 'Petti', 'b89ejsh5643', ''),
(8, 'caioaraujo@gmail.com', 'Caio', '54675867', ''),
(10, 'raul@gmail.com', 'Raul', '96105657865123-8962', ''),
(11, 'oliveiravictor@gmail.com', 'Victor', '549843v', ''),
(12, 'joaoinacio@gmail.com', 'João', '27263958ji', ''),
(13, 'joaocarapina@gmail.com', 'Teteu', '356123874,320', ''),
(14, 'barroso@gmail.com', 'Hendos', '64350785', ''),
(15, 'marcelogomes@gmail.com', 'Marcelo', '1321534535', '');

-- --------------------------------------------------------

--
-- Estrutura para tabela `servicos`
--

DROP TABLE IF EXISTS `servicos`;
CREATE TABLE IF NOT EXISTS `servicos` (
  `cod` int NOT NULL AUTO_INCREMENT,
  `servico` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `descricao` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `preco` decimal(6,2) NOT NULL,
  PRIMARY KEY (`cod`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `servicos`
--

INSERT INTO `servicos` (`cod`, `servico`, `descricao`, `preco`) VALUES
(1, 'Banho e tosa', 'serviço de banho e tosa para seu pet', 150.00),
(2, 'Consulta Veterinária', 'avalie a saúde de seu pet com uma consulta online', 80.00),
(3, 'Hotel pet', 'desfrute uma diária em nosso hotel pet', 105.00),
(4, 'Taxi Pet', 'uma viagem segura de até 10km', 25.00);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
