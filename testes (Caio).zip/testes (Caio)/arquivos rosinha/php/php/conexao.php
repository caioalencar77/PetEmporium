<?php
$con=mysqli_connect("m1629_rosa.mysql.dbaas.com.br","m1629_rosa","ROSA123456a#","m1629_rosa");  // o usuario e a senha do banco e o nome do banco de dados
?>