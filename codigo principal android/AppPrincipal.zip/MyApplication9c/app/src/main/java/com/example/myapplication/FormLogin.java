package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class FormLogin extends AppCompatActivity {

    private TextView text_tela_cadastro;
    private Button bt_entrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_login);

       text_tela_cadastro=findViewById(R.id.text_tela_cadastro);
       bt_entrar=findViewById(R.id.bt_entrar);

       text_tela_cadastro.setOnClickListener(view->{
           startActivity(new Intent(this,FormCadastro.class));
        });
       bt_entrar.setOnClickListener(view->{
           startActivity(new Intent(this,MainActivity.class));
       });


    }

}