package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class comecarj extends AppCompatActivity {

    private Button btnenter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.comecar);

        btnenter = findViewById(R.id.btnenter);

        btnenter.setOnClickListener(view ->{
            startActivity(new Intent(this,FormLogin.class));
        });
    }
}