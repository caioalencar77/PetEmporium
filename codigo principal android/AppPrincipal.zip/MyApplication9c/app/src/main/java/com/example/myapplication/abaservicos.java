package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class abaservicos extends AppCompatActivity {
    private TextView title;
    private ImageView btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.aba_servicos);

        title = findViewById(R.id.title);
        btnVoltar = findViewById(R.id.btnVoltar);

        //adicionando a função

        title.setOnClickListener(view -> {
            startActivity(new Intent(this,MainActivity.class));
        });
        btnVoltar.setOnClickListener(view ->{
            startActivity(new Intent(this,MainActivity.class));
        });
    }
}